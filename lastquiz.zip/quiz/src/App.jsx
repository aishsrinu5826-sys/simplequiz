import React, { useMemo, useState } from 'react'
import SubjectSelect from './components/SubjectSelect.jsx'
import Quiz from './components/Quiz.jsx'
import Results from './components/Results.jsx'
import AttemptTable from './components/AttemptTable.jsx'
import Stats from './components/Stats.jsx'
import QUESTIONS from './data/questions.js'
import { saveAttempt } from './lib/storage.js'

export default function App() {
  const [student, setStudent] = useState({ name: '', id: '' })
  const [subject, setSubject] = useState('')
  const [stage, setStage] = useState('intro') // intro | quiz | results
  const [answers, setAnswers] = useState([])

  const subjectQuestions = useMemo(() => (subject ? QUESTIONS[subject] : []), [subject])

  function startQuiz() {
    if (!student.name.trim() || !student.id.trim() || !subject) return
    setAnswers(Array(subjectQuestions.length).fill(null))
    setStage('quiz')
  }

  function submitQuiz() {
    const score = answers.reduce((acc, a, i) => acc + (a === subjectQuestions[i].answer ? 1 : 0), 0)
    const attempt = {
      ts: Date.now(),
      student,
      subject,
      score,
      total: subjectQuestions.length,
      answers,
    }
    saveAttempt(attempt)
    setStage('results')
  }

  function resetAll() {
    setStage('intro')
    setSubject('')
    setAnswers([])
  }

  return (
    <div className="container">
      <h1>ISE Quiz App</h1>
      {stage === 'intro' && (
        <div className="card">
          <h2>Enter Details</h2>
          <div className="row">
            <label>
              Name
              <input
                value={student.name}
                onChange={(e) => setStudent((s) => ({ ...s, name: e.target.value }))}
                placeholder="Student name"
              />
            </label>
            <label>
              ID / Roll
              <input
                value={student.id}
                onChange={(e) => setStudent((s) => ({ ...s, id: e.target.value }))}
                placeholder="Roll number"
              />
            </label>
          </div>
          <SubjectSelect subject={subject} setSubject={setSubject} onStart={startQuiz} />
        </div>
      )}

      {stage === 'intro' && (
        <Stats />
      )}

      {stage === 'quiz' && (
        <Quiz
          questions={subjectQuestions}
          answers={answers}
          setAnswers={setAnswers}
          onSubmit={submitQuiz}
          onCancel={resetAll}
          subject={subject}
          student={student}
        />
      )}

      {stage === 'results' && (
        <Results
          subject={subject}
          student={student}
          questions={subjectQuestions}
          answers={answers}
          onRestart={resetAll}
        />
      )}

      <AttemptTable />
    </div>
  )
}
