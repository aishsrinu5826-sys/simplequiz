import React, { useEffect, useMemo, useState } from 'react'
import { getAttempts } from '../lib/storage.js'

const SUBJECTS = [
  { key: 'dsa', label: 'DSA' },
  { key: 'java', label: 'Java' },
  { key: 'python', label: 'Python' },
  { key: 'cpp', label: 'C++' },
  { key: 'c', label: 'C' },
]

export default function Stats() {
  const [attempts, setAttempts] = useState([])
  useEffect(() => setAttempts(getAttempts()), [])

  const stats = useMemo(() => {
    const bySubj = {}
    for (const s of SUBJECTS) bySubj[s.key] = { count: 0, best: 0, avgPercent: 0 }
    for (const a of attempts) {
      const key = a.subject
      if (!bySubj[key]) continue
      bySubj[key].count += 1
      bySubj[key].best = Math.max(bySubj[key].best, a.score)
      const pct = (a.score / a.total) * 100
      bySubj[key].avgPercent += pct
    }
    for (const k of Object.keys(bySubj)) {
      const s = bySubj[k]
      if (s.count > 0) s.avgPercent = +(s.avgPercent / s.count).toFixed(1)
      else s.avgPercent = 0
    }
    return bySubj
  }, [attempts])

  return (
    <div className="card">
      <h2>Subject Stats</h2>
      <div className="table">
        <div className="thead">
          <div>Subject</div>
          <div>Attempts</div>
          <div>Best (raw)</div>
          <div>Avg %</div>
        </div>
        {SUBJECTS.map((s) => (
          <div className="trow" key={s.key}>
            <div>{s.label}</div>
            <div>{stats[s.key]?.count ?? 0}</div>
            <div>{stats[s.key]?.best ?? 0}</div>
            <div>{stats[s.key]?.avgPercent ?? 0}%</div>
          </div>
        ))}
      </div>
    </div>
  )
}
