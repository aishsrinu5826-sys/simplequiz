import React, { useMemo } from 'react'

export default function Results({ subject, student, questions, answers, onRestart }) {
  const score = useMemo(() => answers.reduce((acc, a, i) => acc + (a === questions[i].answer ? 1 : 0), 0), [answers, questions])
  const total = questions.length
  const percent = Math.round((score / total) * 100)

  return (
    <div className="card">
      <h2>Results</h2>
      <p><strong>{student.name}</strong> ({student.id}) • <strong>{subject.toUpperCase()}</strong></p>
      <p><strong>Score:</strong> {score} / {total} ({percent}%)</p>

      <details>
        <summary>Show answers</summary>
        <ol>
          {questions.map((q, i) => {
            const correct = q.answer
            const chosen = answers[i]
            const isCorrect = chosen === correct
            return (
              <li key={i} className="qa">
                <div className="q">{q.prompt}</div>
                <div className={`a ${isCorrect ? 'ok' : 'bad'}`}>
                  Your answer: {chosen != null ? q.options[chosen] : 'Not answered'}
                  {!isCorrect && (
                    <span className="muted"> • Correct: {q.options[correct]}</span>
                  )}
                </div>
              </li>
            )
          })}
        </ol>
      </details>

      <button onClick={onRestart}>Back to Home</button>
    </div>
  )
}
