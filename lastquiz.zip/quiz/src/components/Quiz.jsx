import React, { useState } from 'react'

export default function Quiz({ questions, answers, setAnswers, onSubmit, onCancel, subject, student }) {
  const [index, setIndex] = useState(0)
  const q = questions[index]
  const progress = `${index + 1} / ${questions.length}`

  function selectOption(i) {
    const next = [...answers]
    next[index] = i
    setAnswers(next)
  }

  const canPrev = index > 0
  const canNext = index < questions.length - 1
  const allAnswered = answers.filter((a) => a !== null).length === questions.length

  return (
    <div className="card">
      <div className="row space-between">
        <h2>{q.prompt}</h2>
        <div className="muted">{progress}</div>
      </div>
      <div className="options">
        {q.options.map((opt, i) => (
          <label key={i} className={`option ${answers[index] === i ? 'selected' : ''}`}>
            <input
              type="radio"
              name={`q-${index}`}
              checked={answers[index] === i}
              onChange={() => selectOption(i)}
            />
            <span>{opt}</span>
          </label>
        ))}
      </div>
      <div className="row space-between">
        <div>
          <button onClick={() => setIndex((x) => x - 1)} disabled={!canPrev}>Previous</button>
          <button onClick={() => setIndex((x) => x + 1)} disabled={!canNext}>Next</button>
        </div>
        <div>
          <button className="ghost" onClick={onCancel}>Cancel</button>
          <button onClick={onSubmit} disabled={!allAnswered}>Submit</button>
        </div>
      </div>
      <div className="muted small">Student: {student.name} ({student.id}) • Subject: {subject.toUpperCase()}</div>
    </div>
  )
}
