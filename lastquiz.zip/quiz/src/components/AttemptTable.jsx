import React, { useEffect, useMemo, useState } from 'react'
import { getAttempts, clearAttempts } from '../lib/storage.js'

const SUBJECT_LABELS = {
  dsa: 'DSA',
  java: 'Java',
  python: 'Python',
  cpp: 'C++',
  c: 'C',
}

export default function AttemptTable() {
  const [attempts, setAttempts] = useState([])
  useEffect(() => setAttempts(getAttempts()), [])

  const rows = useMemo(() => attempts
    .slice()
    .sort((a, b) => b.ts - a.ts)
    .slice(0, 20), [attempts])

  return (
    <div className="card">
      <div className="row space-between">
        <h2>Recent Attempts</h2>
        <div className="row">
          <button className="ghost" onClick={() => exportCSV(attempts)}>Export CSV</button>
          <button className="ghost" onClick={() => { clearAttempts(); setAttempts([]) }}>Clear</button>
        </div>
      </div>
      {rows.length === 0 ? (
        <p className="muted">No attempts yet.</p>
      ) : (
        <div className="table">
          <div className="thead">
            <div>Date</div>
            <div>Student</div>
            <div>Subject</div>
            <div>Score</div>
          </div>
          {rows.map((r) => (
            <div className="trow" key={r.ts}>
              <div>{new Date(r.ts).toLocaleString()}</div>
              <div>{r.student.name} ({r.student.id})</div>
              <div>{SUBJECT_LABELS[r.subject]}</div>
              <div>{r.score} / {r.total}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function exportCSV(attempts) {
  if (!attempts || attempts.length === 0) return
  const headers = ['timestamp','date','name','id','subject','score','total','percent']
  const lines = [headers.join(',')]
  for (const a of attempts) {
    const percent = ((a.score / a.total) * 100).toFixed(2)
    const row = [
      a.ts,
      new Date(a.ts).toISOString(),
      safe(a.student?.name),
      safe(a.student?.id),
      safe(a.subject),
      a.score,
      a.total,
      percent,
    ]
    lines.push(row.map(csvEscape).join(','))
  }
  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = 'attempts.csv'
  link.style.display = 'none'
  document.body.appendChild(link)
  link.click()
  setTimeout(() => {
    URL.revokeObjectURL(url)
    document.body.removeChild(link)
  }, 0)
}

function safe(v){ return v == null ? '' : String(v) }
function csvEscape(v){
  const s = String(v)
  if (s.includes(',') || s.includes('\"') || s.includes('\n')) {
    return '"' + s.replaceAll('"', '""') + '"'
  }
  return s
}
