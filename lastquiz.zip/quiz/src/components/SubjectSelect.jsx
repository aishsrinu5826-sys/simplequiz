import React from 'react'

const subjects = [
  { key: 'dsa', label: 'DSA' },
  { key: 'java', label: 'Java' },
  { key: 'python', label: 'Python' },
  { key: 'cpp', label: 'C++' },
  { key: 'c', label: 'C' },
]

export default function SubjectSelect({ subject, setSubject, onStart }) {
  return (
    <div className="subject-select">
      <h2>Select Subject</h2>
      <div className="row">
        <select value={subject} onChange={(e) => setSubject(e.target.value)}>
          <option value="">-- Choose subject --</option>
          {subjects.map((s) => (
            <option key={s.key} value={s.key}>{s.label}</option>
          ))}
        </select>
        <button onClick={onStart} disabled={!subject}>Start Quiz</button>
      </div>
    </div>
  )
}
