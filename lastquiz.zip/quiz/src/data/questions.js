const create = (prompt, options, answer) => ({ prompt, options, answer })

const dsa = [
  create('What is the time complexity of binary search?', ['O(n)', 'O(log n)', 'O(n log n)', 'O(1)'], 1),
  create('Which data structure uses FIFO?', ['Stack', 'Queue', 'Tree', 'Graph'], 1),
  create('Which traversal visits root-left-right?', ['Inorder', 'Preorder', 'Postorder', 'Level order'], 1),
  create('What does a hash function do?', ['Encrypts data', 'Maps keys to indices', 'Sorts data', 'Compresses data'], 1),
  create('Best case of quicksort?', ['O(n^2)', 'O(n)', 'O(log n)', 'O(n log n)'], 3),
  create('Height of a complete binary tree with n nodes?', ['log2 n', 'n', 'sqrt n', 'n log n'], 0),
  create('Which finds shortest path (non-negative weights)?', ['DFS', 'Prim', 'Dijkstra', 'Kruskal'], 2),
  create('Which is not stable?', ['Merge sort', 'Quick sort', 'Insertion sort', 'Bubble sort'], 1),
  create('Which DS for LRU cache?', ['Stack', 'Set', 'Queue + HashMap', 'Trie'], 2),
  create('In a BST, inorder traversal gives?', ['Random', 'Descending', 'Ascending', 'Level order'], 2),
]

const java = [
  create('Which is not a Java primitive?', ['int', 'boolean', 'string', 'char'], 2),
  create('JVM stands for?', ['Java Visual Machine', 'Java Virtual Machine', 'Just Virtual Machine', 'Java Version Manager'], 1),
  create('Which keyword prevents inheritance?', ['static', 'final', 'private', 'abstract'], 1),
  create('Default value of uninitialized instance int?', ['0', '1', 'null', 'undefined'], 0),
  create('Which collection allows duplicates?', ['Set', 'List', 'Map keys', 'EnumSet'], 1),
  create('Checked exception example?', ['NullPointerException', 'IOException', 'ArithmeticException', 'ClassCastException'], 1),
  create('Which creates a thread?', ['new Thread()', 'implements Runnable', 'extends Thread', 'All of these'], 3),
  create('String is...', ['mutable', 'immutable', 'thread', 'primitive'], 1),
  create('Which loop guarantees one execution?', ['for', 'while', 'do-while', 'enhanced for'], 2),
  create('Package keyword?', ['package', 'pkg', 'namespace', 'module'], 0),
]

const python = [
  create('Which creates a list?', ['{}', '[]', '()', 'set()'], 1),
  create('PEP 8 relates to...', ['performance', 'style guide', 'packaging', 'security'], 1),
  create('Which is falsey?', ['1', "'0'", '[]', '[0]'], 2),
  create('Keyword for function?', ['def', 'func', 'function', 'lambda def'], 0),
  create('Which is immutable?', ['list', 'dict', 'set', 'tuple'], 3),
  create('Virtual env tool?', ['pip', 'venv', 'npm', 'conda only'], 1),
  create('List comprehension syntax?', ['[x for x in it]', '(x in it)', '{x: it}', 'x: for it'], 0),
  create('Which prints keys of dict d?', ['print(d.keys())', 'print(keys(d))', 'print(d.get())', 'print(d.items[0])'], 0),
  create('Range(5) yields...', ['0..5 inclusive', '0..4', '1..5', '5..10'], 1),
  create('Which opens file for reading?', ["open('a.txt','r')", "open('a.txt','w')", "open('a.txt','a')", "open('a.txt','x')"], 0),
]

const cpp = [
  create('Which is not C++ container?', ['vector', 'map', 'array', 'dictionary'], 3),
  create('RAII stands for...', ['Resource Allocation Is Initialization', 'Resource Acquisition Is Initialization', 'Runtime Allocation Is Initialization', 'Random Access Initialization'], 1),
  create('Which casts safely at runtime?', ['static_cast', 'reinterpret_cast', 'dynamic_cast', 'const_cast'], 2),
  create('Default access in class?', ['public', 'private', 'protected', 'package'], 1),
  create('std::move indicates...', ['copy', 'delete', 'rvalue move', 'constness'], 2),
  create('Header guards prevent...', ['linking', 'multiple definition', 'runtime error', 'I/O'], 1),
  create('Which is not polymorphism?', ['overloading', 'overriding', 'templates', 'virtual'], 2),
  create('Which iterator invalidation is common?', ['vector push_back may reallocate', 'list push_back invalidates all', 'map insert invalidates all', 'set erase invalidates none'], 0),
  create('Smart pointer without ownership transfer?', ['unique_ptr', 'shared_ptr', 'weak_ptr', 'auto_ptr'], 2),
  create('Inline function hint keyword?', ['inline', 'static', 'constexpr', 'mutable'], 0),
]

const c = [
  create('Sizeof char in C is...', ['1 byte', '2 bytes', '4 bytes', 'implementation defined'], 0),
  create('Which is not a storage class?', ['auto', 'register', 'volatile', 'extern'], 2),
  create('Which header for printf?', ['stdio.h', 'stdlib.h', 'string.h', 'ctype.h'], 0),
  create('Array indexing starts at...', ['1', '0', '-1', 'implementation defined'], 1),
  create('Which is not loop?', ['for', 'foreach', 'while', 'do-while'], 1),
  create('Pointer to pointer type?', ['int*', 'int**', 'int&', 'ptr<int>'], 1),
  create('Which frees malloc memory?', ['free', 'delete', 'dispose', 'release'], 0),
  create('Const correct way to define constant?', ['#define PI 3.14', 'const float PI=3.14', 'both valid', 'none'], 2),
  create('Which operator has highest precedence?', ['++', '+', '&&', '=='], 0),
  create('EOF indicates...', ['end of function', 'end of file', 'error of file', 'none'], 1),
]

const QUESTIONS = { dsa, java, python, cpp, c }
export default QUESTIONS
